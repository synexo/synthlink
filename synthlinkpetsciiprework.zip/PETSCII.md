# PETSCII — prework, and the plan for the part that isn't done

Pick-up point for a session implementing PETSCII support. Assumes no memory of
how we got here, and assumes CLAUDE.md and FONTS.md have been read first —
especially FONTS.md §11, which this follows and, in two places, deliberately
departs from.

**Status: the font and the tables are done and verified; nothing is wired.** No
file under `public/` other than the two new assets exists because of this work,
`public/fonts/index.js` has no entry, `main.js` and `terminal.js` have no diff,
and nothing imports `fonts/petscii.js`. `node tools/tests/petsciitest.js` is
14/14 green standing alone. That was deliberate: the font half is provable
without a design decision, and the terminal half is not.

---

## 1. What is in this bundle

| file | what it is |
|---|---|
| `public/fonts/petscii.js` | the two 256-entry tables, generated |
| `public/fonts/Bescii_PETSCII.woff2` | the shipped face, 3.9 KB, 154 glyphs |
| `tools/datasource/Bescii_PETSCII.ttf` | its source asset, per FONTS.md §6.3's rule |
| `tools/datasource/Bescii_PETSCII_proof.txt` | both sets rendered as ASCII, for eyeballing |
| `tools/mkpetscii.py` | generates `petscii.js` from upstream BESCII |
| `tools/besciisubset.py` | mints the `.ttf` from upstream BESCII |
| `tools/petscii-derive.js` | measures the design grid |
| `tools/petscii-romdiff.py` | measures the face against the real C64 character ROM |
| `tools/tests/petsciitest.js` | what can be asserted before anything is wired |

Each script's docstring is the authority on what it does; this document is the
authority on *why any of it*, and on what is left.

Upstream is **BESCII v2.0** (`Bescii-Mono.ttf`), an 8×8 pixel font based on
PETSCII by Damián Vila, **CC0 1.0**. It was on GitHub at `damianvila/font-bescii`
and that repository is now archived; it lives at
`codeberg.org/Dmian/font-bescii`. Both the v1.2 and v2.0 files are inputs to
`mkpetscii.py` — see §4.

CC0 is a waiver, not a ShareAlike licence, so nothing here inherits an
obligation the way the four adapted VileR faces do. The credit in
`public/about.html` is still required by this repo's own rule that a SERVED font
is credited whether or not it is `hidden`, and PROVENANCE.md still takes the
origin and the adaptation. Neither has been written — see §8.

---

## 2. The choice of face, and where it departs from FONTS.md §11.3

**BESCII is not the Commodore 64 character ROM and does not claim to be.** Its
author describes it as inspired by PETSCII "with some modifications to correct a
few flaws, and a unique idiosyncracy". That means **§11.3 step 3 — pin the FACE
by diffing against SyncTERM's `allfonts.c` — cannot be satisfied here, and
should not be attempted.** Topaz was pinned that way because the goal was the
Amiga's own face; the goal here is a *legible modern* rendering of PETSCII on a
phone, which is a different goal and a deliberate one.

That deviation is recorded rather than hidden because it has a cost, and the
cost has now been **measured against the real character ROM** rather than
guessed at. `tools/petscii-romdiff.py` folds every canonical PETSCII code to its
screen code, reads that glyph out of the C64 US character ROMs carried by the
Ultimate Commodore 64 Reference (`mist64/c64ref`, `bin/c64_us_upper.bin` and
`bin/c64_us_lower.bin`), and compares it with BESCII's glyph for the codepoint
`petscii.js` names:

```
unshifted: 86/128 glyphs pixel-identical to the ROM (67.2%), 42 differ, 6.27% of pixels differ
shifted:   77/128 glyphs pixel-identical to the ROM (60.2%), 51 differ, 6.85% of pixels differ
```

**Two thirds of the set is the C64's exactly, and the differences are almost
entirely letterforms**: the worst offenders are `W`, `M`, `$`, `=`, `&`, `4`,
`#`, `@` and `w`/`m` — the "improved x-height and wider strokes" the author
advertises. The graphics that carry PETSCII art are largely untouched. Three
symbol differences are worth knowing: `○` (0xD7) is redrawn wholesale, `♥` and
`♣` differ by a few pixels, and — the one that could actually matter — the
medium shade `▒` in the shifted set (0xDE) is drawn at the **opposite
checkerboard phase** from the ROM, which changes how a field of it tiles against
its neighbours.

**An earlier draft of this document claimed BESCII collapses four pairs of
distinct PETSCII codes into one glyph. That was wrong and is withdrawn.** The
pairs — 0xC0/0xC3, 0xC2/0xDD, 0xA5/0xB4 and 0xA7/0xAA — are **identical on real
hardware too**, verified glyph-for-glyph against the ROM. BESCII is faithful
there and the finding was an artefact of checking for duplicates without knowing
which positions the machine itself duplicates. (The same draft named two of them
by their echo codes, 0x60/0x63 and 0x62/0x7D, which made it worse — see the
aliasing rule in §4.)

The remaining honest statement is the one the numbers support: **BESCII is a
legible modern PETSCII, roughly two thirds pixel-identical to the C64, with the
divergence concentrated in the letters rather than the graphics.** Whether that
trade is the right one is §7.3, and it is reversible — the table is generated
from whatever face it is pointed at.

---

## 3. Aspect and the design grid — both measured, not chosen

### The aspect is 1.2, and it is the machine's

Upstream is a faithful tracing of an 8×8 pixel grid on **square** units: upem
1024, advance 1024, ascent 896 + descent 128, so one source pixel is 128 units
on both axes and the cell presents at 1.000. That is a statement about the
tracing, not about the machine — exactly Topaz's situation, which arrived at
1.600 and needed correcting.

C64 text is 320×200 in a 4:3 raster, so the pixel is **1.2 times taller than
wide** — `320/(200/0.75)` — and a 40×25 terminal lands at 320×240, which is 4:3
exactly. Note the Amiga took 2.4 by the identical route (640×200 in the same
raster) and the C64 takes precisely half of it, because it is half the horizontal
resolution on the same display. Two independent derivations, one consistent
story.

**This is the load-bearing surprise of the whole exercise.** The 40-column mode
that exists today — `vga9x14`, a deliberately squashed 9×14 — presents at 360×350,
terminal aspect **1.029**, and that is the tallest box in the codebase; FONTS.md
§6.4 records it as 1.56× the reference height rather than the 2× an 8-wide font
would cost. An authentic PETSCII terminal is **1.333**, which is *shorter*:

| mode | cell | terminal | aspect | at Dw = 1080 |
|---|---|---|---|---|
| Squat, `vga9x14` @ 40 col | 27 × 42 | 360 × 350 | 1.029 | 1080 × **1050** |
| **PETSCII, 8 × 9.6 @ 40 col** | 27 × 32.4 | 320 × 240 | **1.333** | 1080 × **810** |
| Topaz @ 80 col | — | — | 1.333 | 1080 × 810 |
| Pixel @ 80 col | — | — | 1.347 | 1080 × 802 |

So authenticity is free here: the C64's own correction gives a box 23% shorter
than the 40-column mode already accepted, landing on the same 4:3 shape Topaz
presents and within 1% of Pixel. Cell width is unchanged at 27 device pixels, and
BESCII's capitals fill 7 of the 8 rows, so **letterforms get bigger while the box
gets shorter**. That should still be confirmed on a real device before it is
believed — it is an arithmetic claim about a layout that has never run.

### Getting there: uniform ×1.25, then Y ×1.2

A straight Y ×1.2 at upem 1024 does not land on whole coordinates (128 × 1.2 =
153.6), and FONTS.md §11.3 step 4 says to take the factor that keeps coordinates
whole. So `besciisubset.py` scales the file **uniformly** by 1.25 first — upem
1024 → 1280, every coordinate and every `hmtx` value together — and only then
stretches Y by 1.2. The source pixel ends up 160 units wide and 192 tall, both
exact, with nothing to round.

**Touching X is safe here and this is the second departure from §11.3.** That
step says to prefer scaling Y because `hmtx` is X-only and a non-uniform X change
can desynchronise `lsb` from `glyf`'s `xMin` (§7.1). A *uniform* scale moves both
by the same factor, so it cannot. `besciisubset.py` asserts `lsb == xMin` for
every glyph at the end rather than resting on the argument, and `petsciitest.js`
§5 asserts it again from the shipped file.

Result: upem 1280, advance 1280, ascent 1344 (7 source pixels), descent 192 (1),
cell aspect exactly 1.2000.

### The design grid is 20×24, and it was measured

The cell-aspect invariant `cellW × (ascent + descent) == cellH × advance` forces
`cellH = cellW × 1.2`, leaving 5×6, 10×12, 15×18, 20×24 and 25×30 under the
`cellW ≤ 32` limit. `tools/petscii-derive.js` rasterizes the face at each grid
exactly as `deriveOutlineBitmap()` does, samples each of the 8×8 source pixels at
its block centre (§11.3 step 5), and compares against a 80×96 reference where
every source-pixel boundary lands on a whole device pixel:

```
  grid    px/source  fontSize  baseline  misread%   worst glyph
  5x6     0.625      5         rounded   14.982     U+003D (22/64)
  10x12   1.25       10        rounded   5.668      U+2592 (28/64)
  15x18   1.875      15        rounded   0.071      U+003D (5/64)
  20x24   2.5        20        exact     0          none
  25x30   3.125      25        rounded   0          none
```

**20×24 is the pick**: the smallest grid that reproduces the face exactly, and —
uniquely among the legal pairs — the one where `outlineMetrics()`'s baseline
lands on a whole number (20 × 1344/1280 = 21), so the rasterizer is not asked to
place a pixel grid on a half-pixel origin. The 10×12 figure at 5.7% is the same
failure Topaz hit at 10×24 with 6.8%, from the same cause.

A grid exact on *both* axes would need `cellW` divisible by 8 and by 5 at once,
so 40×48 — past the 32 limit, exactly as Topaz's 40×96 was. This is not a new
problem and needs no new answer.

---

## 4. The tables, and why they are derived from the font itself

PETSCII is **two** 256-entry tables, and the entries are scattered across box
drawing, block elements, geometric shapes and a private-use area. Latin-1 was one
line of Python because it is the identity map; this is 512 codepoints, and typing
them is how a wrong box-drawing character nobody inspects closely ships.

`mkpetscii.py` resolves every position from **BESCII's own two releases**, which
is both mechanical and licence-clean:

1. BESCII **v1.2** carries style64.org's *Direct PETSCII* mapping in its cmap —
   PETSCII code N at `U+E000+N` unshifted and `U+E100+N` shifted. That answers
   "which glyph is code N".
2. BESCII **v2.0** moved almost all of that to real Unicode, keeping the
   private-use area only for the ~20 glyphs with no Unicode equivalent at all.
   Asking v1.2's *own cmap* which other codepoints share a glyph gives the
   author's own Unicode equivalence — exact, and immune to a glyph being
   redrawn between releases. Only where there is no such alias does the script
   fall back to matching the 8×8 rasterized bitmap into v2.0.
3. The rest is structural fact about the machine, not a table: `0x00–0x1F` and
   `0x80–0x9F` are control codes; the shifted set is the unshifted one with three
   letter runs case-swapped, plus exactly the positions v1.2 defines a separate
   `U+E1xx` glyph for; and **the aliasing rule** below.

**The aliasing rule, and it is easy to trip over.** sta.c64.org's PETSCII table
states it plainly: *"Codes $60-$7F and $E0-$FE are not used. Although you can
print them, these are, actually, copies of codes $C0-$DF and $A0-$BE."* `0xFF`
copies `0xDE`. So the **canonical** printable set is `0x20–0x5F`, `0xA0–0xBF` and
`0xC0–0xDF` — 128 positions — and the other two runs are echoes. Anything that
reasons about "which codes are distinct" has to use the canonical set or it will
report nonsense; §2's withdrawn claim is exactly that mistake. `petsciitest.js`
§2 now asserts the full rule in both sets rather than spot-checking two
positions, and `petscii-romdiff.py` measures only the canonical 128.

**Why not `cbmcodecs2`.** The obvious source — the Python package that ships
PETSCII codecs — is **GPL-2.0-only**, which is the same incompatibility
HANDOFF.md already names for linmodem: GPL-2.0-only does not combine with this
repo's GPL-3.0. It is a fine thing to cross-check against by hand and a bad thing
to derive a shipped table from.

**Run as a cross-check anyway, this table agrees at 146 of the comparable
unshifted positions and 172 of the shifted ones, and differs at three glyphs —
every one of them in this table's favour:**

| position | this table | the general-purpose table | why ours |
|---|---|---|---|
| `0xA5`/`0xE5` | U+258E left one **quarter** | U+258F left one **eighth** | the C64's left bar is 2 px wide; BESCII correctly draws U+258F 1 px |
| `0xA7`/`0xE7` | U+E0A0 (private) | U+2595 right one eighth | same, on the right — Unicode has no "right one quarter" |
| `0x71`/`0xD1` | U+2022 bullet | U+25CF black circle | BESCII's own cmap aliases the PETSCII circle to U+2022 |

The alias-driven resolution recovering the fidelity points unprompted is the
strongest evidence the method is right.

**The private-use entries are not a hack.** An entry in `0xE000–0xF8FF` means
"this glyph exists only in this font", which is why the table and the face cannot
be separated — a different PETSCII face would need its own table. That is
FONTS.md §11.1's "one id settles three things" restated.

---

## 5. What the architecture does not have — the actual work

### 5.0 WHICH PETSCII — and this is the prerequisite for everything below

**Everything in §5.2 was derived from the Commodore 64 hardware, not from the
dialect a BBS actually speaks, and that is a gap rather than a decision.** The
two are not the same question:

- *PETSCII the character encoding* is a property of the machine. The tables in
  this bundle are that, they are verified against the character ROM (§2), and
  they do not depend on how any BBS behaves.
- *PETSCII the terminal dialect* is what a C64 board sends and what a modern
  terminal is expected to do with it. **The reference implementation for that is
  SyncTERM/CTerm's PETSCII emulation**, whose manual has its own subsections for
  Control Codes, Colour Mapping, Reverse Video, Cursor Movement Details, Font
  Switching, **Known Differences from Hardware** and **Unimplemented Features** —
  the last two being the admission that faithful-to-the-C64 and
  right-for-a-terminal are not the same target.

**I was not able to retrieve the body of those subsections** — the manual at
`syncterm.net/cterm.html` returned its headings and truncated before the code
tables, repeatedly. So the control-code table in §5.2 is *the C64's*, offered as
a starting point and explicitly not as the specification. **Getting CTerm's
actual list is step 1 of §8 and nothing in §5.2 should be implemented before it
lands** — a dialect built from hardware behaviour that CTerm deliberately
diverges from is a terminal that renders real boards wrongly while passing every
test written against the C64.

Two things that can be said now, both of which the existing architecture
accommodates well:

- **PETSCII mode is not negotiated in band.** There is no terminal-type
  handshake for it in practice; SyncTERM carries the emulation as a per-entry
  setting in its dialing directory, and a caller picks it per board. That maps
  exactly onto `config/altfonts.txt` — the operator names the board and the
  board's font id settles the rest, which is FONTS.md §11.1's argument
  unchanged. It is also why §7.2's "mode branch or second parser" is a free
  choice rather than a constrained one.
- **40 columns is the C64's screen, and the registry already ties the column
  count to the font.** §5.3.

Also worth checking against CTerm rather than assuming: whether boards are
reached through Synchronet's own CBM/PETSCII support path (`wiki.synchro.net`
has a howto for it), and whether any of the Java PETSCII BBS frameworks in
common use — `sblendorio/petscii-bbs` is the visible one — emit anything CTerm
does not.

---

Three things, in descending order of how much they change.

### 5.1 PETSCII is two charsets, switched in band, and `charsetOf()` resolves one

`0x0E` selects the shifted (lower/upper) set and `0x8E` the unshifted
(upper/graphics) one. This happens **mid-screen and statefully**: the same byte
is a different character on either side of the switch, `0x41` is `A` then `a`,
and `0x61–0x7A` are graphics then uppercase letters. Which positions are line
graphics *also* differs between the sets, which is the second reason the two
tables cannot be collapsed into one descriptor — `PETSCII_UC_GRAPHICS` has 15
runs and `PETSCII_LC_GRAPHICS` has 7.

Today a charset is resolved **once per font** (`charsetOf(font)`) and consulted
by the atlas builder at atlas-build time. FONTS.md §11.2 states outright that
"the draw path never sees a charset" and that "a change that needs a line in
`renderer.js` or `terminal.js` is the wrong change". **For PETSCII that
statement has to be revisited, because the character a cell holds is no longer a
function of the byte alone.**

The shape that looks right, and the reason:

- The atlas holds **two pages** of 256 glyphs rather than one — the same build,
  run twice, against the two descriptors. Cost is one more atlas sheet, which is
  the same cost the tinted sheets already pay.
- `Terminal` records, per cell, **which page that byte was written under**, the
  way `_wrapped[]` already records line continuation. `putChar` reads the current
  shift state; the renderer reads the recorded flag. FONTS.md §11.4's own
  precedent applies: "line continuation is RECORDED, not inferred" — and shift
  state is the same kind of fact. Anything that moves rows must move the flags,
  and anything that erases a row's tail must clear them.
- The shift state is **session state that survives a clear** and resets on
  carrier, and it must be reset in `cleanup()` beside the font override.

Do not be tempted to decode bytes to characters at receive time and store
characters. `terminal.js` stores raw bytes on purpose; a menu-key click sends the
RAW cell byte precisely because decoding and re-encoding truncates anything above
0x7F (FONTS.md/HANDOFF watch-out). Storing a page flag beside the byte keeps that
property; storing a decoded character destroys it.

**Copy also has to answer this.** `getSelectionText()` takes a charset table
today; with two pages it needs the per-cell page, or an Amiga-style single-table
call will decode half a screen wrongly.

### 5.2 A PETSCII board sends almost no ANSI

This is the bulk of the work, and it is terminal work rather than font work.
Topaz needed *only* a table because an Amiga board still speaks ANSI. A C64 board
does not.

**The table below is the C64's, NOT CTerm's — see §5.0 before using it.** It is
here to size the work and to name the bytes, not to specify the behaviour.

| function | PETSCII | today |
|---|---|---|
| colour, 16 of them | `0x05 0x1C 0x1E 0x1F 0x81 0x90 0x95–0x9F` | ANSI SGR |
| reverse video | `0x12` on, `0x92` off | ANSI SGR 7 — the `reverse` attribute already exists |
| cursor | `0x11` down, `0x91` up, `0x1D` right, `0x9D` left | ANSI CUP/CUU/… |
| home / clear | `0x13` / `0x93` | ANSI CUP / ED |
| insert / delete | `0x94` / `0x14` | ANSI ICH / DCH |
| charset switch | `0x0E` / `0x8E` | see §5.1 |

Note `terminal.js:132` already swallows `0x0E`/`0x0F` as ANSI SO/SI — the same
byte, a different meaning. That line is the first thing a PETSCII mode has to
take over, and it is a good marker for how the two interpretations should be
separated rather than merged: **a board is in PETSCII mode or it is not**, and
the mode is settled by the same `config/altfonts.txt` entry that settles the
font, before the dial, for the reason FONTS.md §11.4 gives about `windowSize()`.

Deciding whether that mode is a second parser or a branch inside the existing one
is a design call this bundle deliberately does not make.

### 5.3 40 columns, which mostly already works

A C64 screen is 40×25 and the registry already ties the column count to the font
(`cols: 40`, and selecting that font **is** how 40-column mode is entered). The
PETSCII entry carries `cols: 40` and inherits that machinery unchanged. §3 has
the aspect consequence, which is favourable.

---

## 6. The registry entry this expects

Not applied — `public/fonts/index.js` is untouched. This is what §8 step 3 should
add, and every number in it is asserted by `petsciitest.js` or measured by
`petscii-derive.js`:

```js
  {
    // ── PETSCII, board-specific. Hidden; its job is boards listed in
    // config/altfonts.txt, exactly as Topaz's is. NOT in the Aa cycle: a
    // board-specific font is not a typeface choice.
    //
    // Design grid 20x24: 20 x 1536 == 24 x 1280. The smallest legal pair that
    // reproduces the face exactly through deriveOutlineBitmap (0.000% against
    // a 80x96 reference; 15x18 misreads 0.071%, 10x12 misreads 5.7%) and the
    // only one whose baseline lands whole. tools/petscii-derive.js measures it.
    //
    // Aspect 1.2 is the C64's, not the file's — see PETSCII.md section 3 and
    // tools/besciisubset.py. cols: 40 because a C64 screen is 40x25, and that
    // pairing is the whole choice.
    hidden: true,
    id: 'bescii8x8',
    uiName: 'PETSCII',
    name: 'BESCII (outline)',
    kind: 'ttf',
    cellW: 20,
    cellH: 24,
    cols: 40,
    file: 'fonts/Bescii_PETSCII.woff2',
    family: 'Bescii Mono',            // name ID 1 of the shipped file
    upem: 1280,
    advance: 1280,
    ascent: 1344,
    descent: 192,
    capHeight: 1344,                  // 7 of 8 rows; measured off 'A' and 'X'
    xHeight: 960,                     // 5 of 8 rows; measured off 'x'
    scale: 'hybrid',
    charset: PETSCII_UC,              // ...and this is where it breaks, see 5.1
  },
```

The last line is the point: **there is no single `charset` for this font**, so
the entry cannot be finished until §5.1 is decided. That is why it is a snippet
in a document rather than a diff.

---

## 7. Open questions that need a human

1. **Two atlas pages, or something else?** §5.1 proposes the shape but it
   changes `terminal.js` and `renderer.js`, which FONTS.md §11.2 currently
   forbids. That document needs to change with the code, and which way is a call
   for whoever owns the design.
2. **A second parser for PETSCII control codes, or a mode branch in the existing
   one?** §5.2.
3. **Is BESCII the right face at all**, given §2's measured 67%/60% agreement
   with the character ROM? A
   faithful C64 arm from SyncTERM's `allfonts.c` is possible and would be less
   legible on a phone. This bundle assumes BESCII and says so; it is reversible,
   because the table is generated from whatever face it is pointed at.
4. **Is there a board to test against?** FONTS.md §11.3 step 1 is unambiguous
   that everything else is guesswork without a wire capture, and there is none
   here. aBSiNTHE's address was not in the repo either and the Topaz work shipped
   anyway — but the control-code half of §5.2 genuinely cannot be finished
   blind.

---

## 8. Suggested order

1. **Get CTerm's PETSCII control-code specification** (§5.0). Nothing about the
   terminal half should be written before it, and it is a document rather than a
   discovery — the manual at `syncterm.net/cterm.html` has it, and if fetching it
   keeps truncating, the SyncTERM source is the fallback.
2. Answer §7.1 and §7.2, now informed by step 1.
3. Get a wire capture from a PETSCII board (§7.4) — SyncTERM `Alt-C`, ANSI/raw.
   Diff it against step 1: what a board really sends is the only thing that
   settles Known Differences from Hardware in this direction.
4. Registry entry (§6) plus whatever §7.1 decides, so the font is reachable.
5. `config/altfonts.txt` gains the board, and whatever carries "this board is
   PETSCII" — note that FONTS.md §11.1 argues hard against a second field there,
   so the mode should ride on the font id like the charset and the column count
   do.
6. The control-code work (§5.2), against CTerm's spec and the capture.
7. `public/about.html` credit and PROVENANCE.md entry. **This is a licence
   obligation under this repo's own rule, not a courtesy**, and it is the step
   most likely to be forgotten because CC0 does not demand it.
8. Wire `petsciitest.js` into `attest.js`, and extend it with whatever §5.1
   lands. Every suite is expected to be green.
9. FONTS.md §11 and HANDOFF.md, last, once the shape is real. Delete this
   document when it is empty, the way PROTOIMPROVE.md is meant to go.

---

## 9. Watch-outs

- **The two tables are not interchangeable and the graphics runs differ.**
  `PETSCII_UC_GRAPHICS` and `PETSCII_LC_GRAPHICS` are both in `petscii.js` for
  that reason. Using one descriptor for both sets edge-extends letters into their
  neighbours in the shifted set.
- **`petscii.js` is generated. Do not hand-edit it** — fix `mkpetscii.py` and
  re-run, or the next upstream release silently reverts the edit.
- **The private-use entries tie the table to BESCII.** Pointing the registry at
  a different PETSCII face without regenerating the table gives `.notdef` boxes
  for around twenty graphics, and only in the middle of somebody's art.
- **Blanking is policy, at the atlas builder** — `petsciiBlank()` is written to
  be that predicate, and the tables stay a faithful transcription. Same rule
  CP437's two positions and Latin-1's C0/C1 follow.
- **`0xA0` and `0xE0` are the shifted space** and blank for the same reason
  CP437 blanks its NBSP. They are not control codes; they are characters that
  draw nothing.
- **Do not use `cbmcodecs2` in anything that ships.** GPL-2.0-only. §4.
- **A rebuild of the asset must re-run `besciisubset.py`, not `mkwoff2.py`
  alone.** `mkwoff2.py` deliberately refuses to subset or transform, so pointing
  it at raw upstream produces a 911-glyph square-aspect file that will present
  20% too wide and pass nothing.
- **`cellW` cannot exceed 32** (`glyphRowBits` packs `stride * 8` bits with
  32-bit shifts). 20 is fine; the 80×96 reference grid inside
  `petscii-derive.js` is a measurement only and never reaches the renderer.
- **The aspect finding in §3 is arithmetic about a layout that has not run.**
  Measure it on a device before repeating it as fact.
- **`0x60–0x7F` and `0xE0–0xFE` are ECHOES, not characters** (§4). Reasoning
  about which PETSCII codes are distinct without excluding them produces
  confident nonsense — it already did once, in the claim §2 withdraws. The
  canonical set is `0x20–0x5F`, `0xA0–0xBF`, `0xC0–0xDF`.
- **Do not implement §5.2 from the C64's control codes.** CTerm's PETSCII
  emulation is the dialect a BBS is written against and it documents its own
  divergences from hardware. §5.0.
