#!/usr/bin/env node
// PETSCII tables and the BESCII face — the assertions that can be made before
// anything is wired up.
//
// ttftest.js owns the outline-font invariants for every entry in the registry.
// This is its counterpart for a font and a charset that are NOT in the registry
// yet: fonts/petscii.js and tools/datasource/Bescii_PETSCII.ttf exist, nothing
// imports them, and PETSCII.md is the plan for the part that does. Everything
// here holds regardless of how that lands, so it is worth having now — a table
// with a wrong codepoint does not crash, it draws the wrong box-drawing
// character on a board nobody here can dial.
//
//   1. EVERY POSITION RESOLVES. All 192 printable positions of both sets must
//      name a codepoint the shipped file actually has a glyph for. This is the
//      same assertion ttftest section 1 makes about CP437, and the same reason:
//      a missing glyph is a .notdef box in the middle of somebody's art.
//
//   2. THE STRUCTURAL RULES HOLD. The shifted set must differ from the unshifted
//      one only where PETSCII says it does — the three letter runs and the
//      positions BESCII v1.2 defines a separate glyph for. A generator bug that
//      shifted a run by one would otherwise be invisible.
//
//   3. THE CONTROL RANGES ARE BLANK. 0x00-0x1F and 0x80-0x9F are PETSCII control
//      codes in both sets. If one of them ever resolves to a character, some
//      board's colour change is about to be drawn as a glyph.
//
//   4. THE CELL-ASPECT INVARIANT, for the entry PETSCII.md proposes. cellW *
//      (ascent + descent) == cellH * advance, read out of the FILE rather than
//      restated, so a re-minted asset that lost the aspect correction fails here
//      rather than presenting stretched.
//
//   5. lsb == xMin FOR EVERY GLYPH. FONTS.md 7.1. besciisubset.py scales X
//      uniformly precisely so this cannot break, which is the kind of claim that
//      should be checked rather than believed.
//
// Reading the .ttf needs no font library, for the reason ttftest gives: this
// parses the tables it needs directly and so cannot be fooled by a stale cache
// in some toolchain.
//
// No DOM, no sockets, instant. `node tools/tests/petsciitest.js`

const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..', '..');
const TTF = path.join(ROOT, 'tools', 'datasource', 'Bescii_PETSCII.ttf');
const JS = path.join(ROOT, 'public', 'fonts', 'petscii.js');

// The design grid PETSCII.md proposes, and the measurement behind it is in
// tools/petscii-derive.js. Restated here because this harness is asserting that
// the FILE can carry it, which is a property of the file.
const CELL_W = 20, CELL_H = 24;

let pass = 0, fail = 0;
function eq(a, e, what) {
  const A = JSON.stringify(a), E = JSON.stringify(e);
  if (A === E) { pass++; return; }
  fail++;
  console.log(`  FAIL ${what}\n       expected ${E}\n       actual   ${A}`);
}
const ok = (cond, what) => eq(!!cond, true, what);

// ── A minimal SFNT reader: cmap format 4, hmtx, glyf/loca ───────────────────
function sfnt(buf) {
  const n = buf.readUInt16BE(4), t = {};
  for (let i = 0; i < n; i++) {
    const o = 12 + i * 16;
    t[buf.toString('latin1', o, o + 4)] =
      { off: buf.readUInt32BE(o + 8), len: buf.readUInt32BE(o + 12) };
  }
  return t;
}

function cmap4(buf, t) {
  const base = t.cmap.off, n = buf.readUInt16BE(base + 2);
  let sub = -1;
  for (let i = 0; i < n; i++) {
    const o = base + 4 + i * 8;
    const pid = buf.readUInt16BE(o), eid = buf.readUInt16BE(o + 2);
    if ((pid === 3 && eid === 1) || (pid === 0)) sub = base + buf.readUInt32BE(o + 4);
  }
  if (sub < 0) throw new Error('no unicode cmap subtable');
  if (buf.readUInt16BE(sub) !== 4) throw new Error('cmap subtable is not format 4');
  const segX2 = buf.readUInt16BE(sub + 6), seg = segX2 >> 1;
  const ends = sub + 14, starts = ends + segX2 + 2;
  const deltas = starts + segX2, ranges = deltas + segX2;
  const map = new Map();
  for (let s = 0; s < seg; s++) {
    const end = buf.readUInt16BE(ends + s * 2), start = buf.readUInt16BE(starts + s * 2);
    const delta = buf.readInt16BE(deltas + s * 2), ro = buf.readUInt16BE(ranges + s * 2);
    if (start === 0xFFFF) continue;
    for (let c = start; c <= end; c++) {
      let g;
      if (ro === 0) g = (c + delta) & 0xFFFF;
      else {
        const at = ranges + s * 2 + ro + (c - start) * 2;
        g = buf.readUInt16BE(at);
        if (g) g = (g + delta) & 0xFFFF;
      }
      if (g) map.set(c, g);
    }
  }
  return map;
}

// ── The tables, parsed out of the module rather than imported ───────────────
// fonts/petscii.js is an ES module in the browser tree; ttftest reads main.js
// the same way and for the same reason. Parsing by NAME means renaming an
// export throws here rather than testing a stale copy.
function table(src, name) {
  const m = src.match(
    new RegExp(`export const ${name} = new Uint16Array\\(\\[([\\s\\S]*?)\\]\\);`));
  if (!m) throw new Error(`${name} not found in petscii.js`);
  const vals = [...m[1].matchAll(/0x([0-9A-Fa-f]{4})/g)].map((x) => parseInt(x[1], 16));
  if (vals.length !== 256) throw new Error(`${name} has ${vals.length} entries, expected 256`);
  return vals;
}

const src = fs.readFileSync(JS, 'utf8');
const UC = table(src, 'PETSCII_UC_TO_UNICODE');
const LC = table(src, 'PETSCII_LC_TO_UNICODE');
const buf = fs.readFileSync(TTF);
const t = sfnt(buf);
const cmap = cmap4(buf, t);

console.log('PETSCII tables + BESCII face');

// ── 1. Every printable position resolves to a real glyph ────────────────────
{
  const missing = [];
  for (const [name, tbl] of [['unshifted', UC], ['shifted', LC]]) {
    for (let i = 0; i < 256; i++) {
      if (!tbl[i]) continue;
      if (!cmap.has(tbl[i])) missing.push(`${name} 0x${i.toString(16)} -> U+${tbl[i].toString(16)}`);
    }
  }
  eq(missing, [], '1. every printable position has a glyph in the shipped face');
  ok(UC.filter((v) => v).length === 192, '1. unshifted has 192 printable positions');
  ok(LC.filter((v) => v).length === 192, '1. shifted has 192 printable positions');
}

// ── 2. The shifted set differs only where PETSCII says it does ──────────────
{
  // The three letter runs, plus the positions BESCII v1.2 gives the shifted set
  // its own glyph for. Both halves are structural: the letter swap is what
  // "shifted" MEANS, and the override list is upstream's, not ours.
  const letters = new Set();
  for (let i = 0x41; i <= 0x5A; i++) letters.add(i);
  for (let i = 0x61; i <= 0x7A; i++) letters.add(i);
  for (let i = 0xC1; i <= 0xDA; i++) letters.add(i);
  const overrides = new Set([0x7E, 0x7F, 0xA9, 0xBA, 0xDE, 0xDF, 0xE9, 0xFA, 0xFF]);

  const unexpected = [];
  for (let i = 0; i < 256; i++) {
    if (UC[i] === LC[i]) continue;
    if (!letters.has(i) && !overrides.has(i)) unexpected.push('0x' + i.toString(16));
  }
  eq(unexpected, [], '2. the two sets differ only at the letter runs and the overrides');

  // and the letter runs are the swap they claim to be
  const bad = [];
  for (let i = 0x41; i <= 0x5A; i++) if (LC[i] !== i + 0x20) bad.push('0x' + i.toString(16));
  for (let i = 0x61; i <= 0x7A; i++) if (LC[i] !== i - 0x20) bad.push('0x' + i.toString(16));
  for (let i = 0xC1; i <= 0xDA; i++) if (LC[i] !== i - 0x80) bad.push('0x' + i.toString(16));
  eq(bad, [], '2. shifted letter positions are the case swap');

  // THE ALIASING RULE, in full and in both sets. sta.c64.org's PETSCII table:
  // "Codes $60-$7F and $E0-$FE are not used. Although you can print them, these
  // are, actually, copies of codes $C0-$DF and $A0-$BE." $FF copies $DE.
  //
  // So 0xC0-0xDF and 0xA0-0xBF are the CANONICAL positions and the other two
  // runs are echoes of them. Worth asserting rather than assuming: the table is
  // generated from a font's cmap, and a font that gave one of the copies its
  // own glyph would put a character on screen that no C64 can produce.
  const echoes = [];
  for (let i = 0x60; i <= 0x7F; i++) {
    if (UC[i] !== UC[i + 0x60] || LC[i] !== LC[i + 0x60]) echoes.push(`0x${i.toString(16)}`);
  }
  for (let i = 0xE0; i <= 0xFE; i++) {
    if (UC[i] !== UC[i - 0x40] || LC[i] !== LC[i - 0x40]) echoes.push(`0x${i.toString(16)}`);
  }
  eq(echoes, [], '2. 0x60-0x7F copies 0xC0-0xDF and 0xE0-0xFE copies 0xA0-0xBE');
  eq([UC[0xFF], LC[0xFF]], [UC[0xDE], LC[0xDE]], '2. 0xFF copies 0xDE');
}

// ── 3. The control ranges are blank in both sets ────────────────────────────
{
  const live = [];
  for (let i = 0; i < 256; i++) {
    const ctrl = i < 0x20 || (i >= 0x80 && i <= 0x9F);
    if (!ctrl) continue;
    if (UC[i] || LC[i]) live.push('0x' + i.toString(16));
  }
  eq(live, [], '3. 0x00-0x1F and 0x80-0x9F are blank in both sets');
  eq([UC[0xA0], LC[0xA0]], [0x00A0, 0x00A0], '3. 0xA0 is the shifted space');
}

// ── 4. The cell-aspect invariant, from the file ─────────────────────────────
{
  const head = t.head.off, hhea = t.hhea.off, hmtx = t.hmtx.off;
  const upem = buf.readUInt16BE(head + 18);
  const ascent = buf.readInt16BE(hhea + 4), descent = buf.readInt16BE(hhea + 6);
  const advance = buf.readUInt16BE(hmtx);            // first hMetric's advance
  eq(upem, 1280, '4. upem is the uniform-scaled 1280');
  eq([ascent, descent], [1344, -192], '4. vertical metrics are 7 and 1 source pixels');
  eq(CELL_W * (ascent - descent), CELL_H * advance,
    `4. cell-aspect invariant: ${CELL_W} x ${ascent - descent} == ${CELL_H} x ${advance}`);
  eq((ascent - descent) / advance, 1.2, '4. the cell presents at the C64 pixel aspect 1.2');
}

// ── 5. lsb == xMin for every glyph with contours ────────────────────────────
{
  const head = t.head.off, maxp = t.maxp.off, hhea = t.hhea.off;
  const longFmt = buf.readInt16BE(head + 50) === 1;
  const numGlyphs = buf.readUInt16BE(maxp + 4);
  const numH = buf.readUInt16BE(hhea + 34);
  const loca = t.loca.off, glyf = t.glyf.off, hmtx = t.hmtx.off;
  const at = (i) => (longFmt ? buf.readUInt32BE(loca + i * 4) : buf.readUInt16BE(loca + i * 2) * 2);
  const lsbOf = (i) => (i < numH ? buf.readInt16BE(hmtx + i * 4 + 2)
    : buf.readInt16BE(hmtx + numH * 4 + (i - numH) * 2));
  const bad = [];
  for (let g = 0; g < numGlyphs; g++) {
    const start = at(g), end = at(g + 1);
    if (end <= start) continue;                       // empty glyph, no xMin
    const xMin = buf.readInt16BE(glyf + start + 2);
    if (lsbOf(g) !== xMin) bad.push(`glyph ${g}: lsb ${lsbOf(g)} != xMin ${xMin}`);
  }
  eq(bad, [], '5. lsb == xMin for every glyph with contours');
}

console.log(`\n  ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
