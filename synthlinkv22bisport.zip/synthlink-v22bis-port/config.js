'use strict';
// Minimal config for a V.22bis + V.8 port. Only keys the DSP subset reads.
module.exports = {
  rtp: { sampleRate: 8000, packetIntervalMs: 20 },
  logging: { level: 'warn', logModemData: false },
  modem: {
    role: 'answer',
    native: {
      protocolPreference: ['V22bis'],
      v8ModulationModes:  ['V22bis'],
      forceProtocol: null,
      advertiseProtocol: null,
      answerToneDelayMs: 1000,
      answerToneDurationMs: 3300,
      trainingDurationMs: { V21: 0, V22: 600, V22bis: 600 },
      blockSizeSamples: 160,
      carrierToleranceHz: 10,
      silenceThreshold: 0.001,
      silenceHangupPackets: 750,
      agcEnabled: false,
      agcTargetLevel: 0.3,
      v22MagOnlyDetect: true,
      cdStableMs: 120,
      listenWindowMs: 12000,
      skipCdVerification: true,
    },
  },
};
