const fs=require('fs');
const config=require('./config');
const {ModemDSP}=require('./src/dsp/ModemDSP');
const A=new ModemDSP('originate'),B=new ModemDSP('answer');
const oa=[],ob=[];
const jit=(d,f)=>d.receiveAudio(f);
A.on('audioOut',f=>{oa.push(...f);jit(B,f)}); B.on('audioOut',f=>{ob.push(...f);jit(A,f)});
B.on('connected',()=>B.write(Buffer.from('READY\r\n')));
A.start();B.start();
setTimeout(()=>{
  const wr=(n,s)=>{const b=Buffer.alloc(44+s.length*2);b.write('RIFF',0);b.writeUInt32LE(36+s.length*2,4);b.write('WAVEfmt ',8);b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(1,22);b.writeUInt32LE(8000,24);b.writeUInt32LE(16000,28);b.writeUInt16LE(2,32);b.writeUInt16LE(16,34);b.write('data',36);b.writeUInt32LE(s.length*2,40);s.forEach((v,i)=>b.writeInt16LE(Math.max(-32767,Math.min(32767,Math.round(v*32767))),44+i*2));fs.writeFileSync(n,b);console.log(n,(s.length/8000).toFixed(2)+'s');};
  wr('orig.wav',oa);wr('ans.wav',ob);
  // crude goertzel spectrum of answer side first 2s
  const g=(s,f)=>{const w=2*Math.PI*f/8000;let c=Math.cos(w),s1=0,s2=0;for(const x of s){const t=x+2*c*s1-s2;s2=s1;s1=t;}return Math.sqrt(s1*s1+s2*s2-2*c*s1*s2)/s.length;};
  const seg=ob.slice(0,16000);
  [1200,1800,2100,2400,980,1650].forEach(f=>console.log(f+'Hz',g(seg,f).toFixed(4)));
  process.exit(0);
},9000);
